import React from 'react';


const Footer = () => {

    return (
        <footer className="footer-copyright text-center fixed-bottom bg-info text-white">
            &copy; RentCar, 2019
        </footer>
    )

};

export default Footer;