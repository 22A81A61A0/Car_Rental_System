package com.server.domain.enums;

public enum SaleType {
    APPROVED,
    DECLINED,
    PENALTY
}
