package com.server.domain.enums;

public enum UserRolesEnum {
    ADMIN,
    USER
}