import React from 'react';


const NotFound = (props) => {

    return (
        <div className="container mt-3">
            <div className="jumbotron text-center shadow">
                <h1 className="">404 Page Not Found</h1>
            </div>
        </div>

    )
}

export default NotFound;