import rentService from './rentService';
import carService from './carService';
import authService from './authService'
import saleService from './saleService'

export {
    rentService,
    carService,
    authService,
    saleService
}