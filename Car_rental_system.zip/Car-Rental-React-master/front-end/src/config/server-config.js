const SERVER_PATH = 'http://localhost:8080';

export default {
    SERVER_PATH
}